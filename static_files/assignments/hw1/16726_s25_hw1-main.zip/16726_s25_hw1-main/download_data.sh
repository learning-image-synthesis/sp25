curl https://www.andrew.cmu.edu/course/16-726-sp25/projects/handouts/proj1/data.zip -O data.zip
unzip data.zip
